
/** Legal actions in a game of Rock-Paper-Scissors. 
 * 
 * @author RR
*/
public enum Action {
    ROCK, PAPER, SCISSORS, LIZARD, SPOCK
}